var mongoose = require("mongoose");

var schemaLaptop = new mongoose.Schema({
    Name: String,
    Image: String,
    Price: Number,
    Type: String,
    Config: {
        Ram: String,
        SSD: String,
        CPU: String,
        GPU: String,
        Screen: String
    },
    Remains: Number
});

module.exports = mongoose.model("Laptop", schemaLaptop);