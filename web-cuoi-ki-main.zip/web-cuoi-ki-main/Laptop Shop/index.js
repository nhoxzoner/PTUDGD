var express = require("express");
var app = express();
app.set("view engine", "ejs");
app.set("views", "./views");
app.use(express.static("public"));
app.listen(3000);

//Mongo
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://minh0812:1@cluster0.cxsho.mongodb.net/Laptop?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true}, function (err) {
    if (err) {
        console.log("Mongo connnect error: " + err);
    }
    else{
        console.log("Mongo connected successfull.");
    }
});


//body-parser
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: false}));

// Models

var Laptop = require("./models/Laptop");
var Khachhang = require("./models/khachhang");

// muter cai nay de upload file
var multer = require("multer");
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/upload')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + "-" + file.originalname);
    }
});

var upload = multer({
    storage: storage,
    fileFilter: function (req, file, cb) {
        console.log(file);
        if (file.mimetype == "image/bmp" || file.mimetype == "image/png" || file.mimetype == "image/jpeg" || file.mimetype == "image/jpg") {
            cb(null, true);
        }
        else{
            return cb(new Error('Only image are allwed!'));
        }
    }
}).single("laptopImage");

// ADD NEW

app.get("/add", function (req, res) {
    res.render("add");
})

app.post("/add", function (req, res) {
    // upload file
    upload(req, res, function(err){
        if (err instanceof multer.MulterError) {
            res.json({"kq": 0, "errMsg":"A Multer error occurred when uploading."});
        }
        else if (err) {
            res.json({"kq": 0, "errMsg": "An unknown error occurred when uploading." + err});
        }
        else{
            // save mongo
            var laptop = Laptop({
                Name: req.body.txtName,
                Image: req.file.filename,
                Price: req.body.txtPrice,
                Type: req.body.txtType,
                Config: {
                    Ram: req.body.txtRam,
                    SSD: req.body.txtSSD,
                    CPU: req.body.txtCPU,
                    GPU: req.body.txtGPU,
                    Screen: req.body.txtScreen
                },
                Remains: req.body.txtRemains
            });
            laptop.save(function (err) {
                if (err) {
                    res.json({"kq": 0, "errMsg": err});
                }
                else{
                    res.redirect("./admin/list")
                }
            })
        }
    });
});

// Danh Sach
app.get("/admin/list", function (req, res) {
    Laptop.find(function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("list",{danhsach:data});
        }
    });
});

// Add so luong
app.get("/add/:id", function (req, res) {
    // lay thong tin chi tiet cua model dang sua
    Laptop.findById(req.params.id, function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("add_old", {laptop : data})
        }
    })
})

app.post("/admin/add", function (req, res) {
    let a = Number.parseInt(req.body.txtRemains);
    let b = Number.parseInt(req.body.txtSoluong);
    console.log(a + b);
    Laptop.updateOne({_id: req.body.IDLaptop}, {
        Remains: a + b
    }, function (err) {
        if (err) {
           res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.redirect("./list");
        }
    })
});

// Danh sach don hang
app.get("/admin/donhang", function (req, res) {
    Khachhang.find(function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("donhang",{danhsach:data});
        }
    });
});

// Delete don hang
app.get("/donhang/delete/:id", function (req, res) {
    Khachhang.deleteOne({_id: req.params.id}, function (err) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.redirect("/admin/donhang");
        }
    })
})

// Edit
app.get("/edit/:id", function (req, res) {
    // lay thong tin chi tiet cua model dang sua
    Laptop.findById(req.params.id, function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("edit", {laptop : data})
        }
    })
})

app.post("/edit", function (req, res) {
   
    // xu ly upload file (Check khach hang co CHON FILE MOI KO)
    upload(req, res, function(err){

        //khach hang ko chon file hinh
        if (!req.file) {
            Laptop.updateOne({_id: req.body.IDLaptop}, {
                Name: req.body.txtName,                
                Price: req.body.txtPrice,
                Type: req.body.txtType,
                Config: {
                    Ram: req.body.txtRam,
                    SSD: req.body.txtSSD,
                    CPU: req.body.txtCPU,
                    GPU: req.body.txtGPU,
                    Screen: req.body.txtScreen
                },
                Remains: req.body.txtRemains
            }, function (err) {
               if (err) {
                   res.json({"kq": 0, "errMsg": err});
               }
               else{
                   res.redirect("./admin/list");
               }
            })
        }
        // khach hang co chon file hinh
        else{
            if (err instanceof multer.MulterError) {
                res.json({"kq": 0, "errMsg":"A Multer error occurred when uploading."});
            }
            else if (err) {
                res.json({"kq": 0, "errMsg": "An unknown error occurred when uploading." + err});
            }
            else{
                // Upload Mongo (req.file.filename)
                Laptop.updateOne({_id: req.body.IDLaptop}, {
                    Name: req.body.txtName,
                    Image: req.file.filename,
                    Price: req.body.txtPrice,
                    Type: req.body.txtType,
                    Config: {
                        Ram: req.body.txtRam,
                        SSD: req.body.txtSSD,
                        CPU: req.body.txtCPU,
                        GPU: req.body.txtGPU,
                        Screen: req.body.txtScreen
                    },
                    Remains: req.body.txtRemains
                }, function (err) {
                    if (err) {
                        res.json({"kq": 0, "errMsg": err});
                    }
                    else{
                        res.redirect("./admin/list");
                    }
                })
            }
        }
    });
});

// delete
app.get("/delete/:id", function (req, res) {
    Laptop.deleteOne({_id: req.params.id}, function (err) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.redirect("../admin/list");
        }
    })
})

// home
app.get("/", function (req, res) {
    res.render("home");
})
// gaming
app.get("/gaming", function (req, res) {
    Laptop.find(function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("gaming",{danhsach:data});
        }
    });
})
// van phong
app.get("/vanphong", function (req, res) {
    Laptop.find(function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("vanphong",{danhsach:data});
        }
    });
})
// workstation
app.get("/workstation", function (req, res) {
    Laptop.find(function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("workstation",{danhsach:data});
        }
    });
})
// bao hanh
app.get("/baohanh", function (req, res) {
    res.render("baohanh");
})
// cau hinh chi tiet may
app.get("/laptop/:id", function (req, res) {
    // lay thong tin chi tiet cua model dang sua
    Laptop.findById(req.params.id, function (err, data) {
        if (err) {
            res.json({"kq": 0, "errMsg": err});
        }
        else{
            res.render("laptop", {laptop : data})
        }
    })
})
// cart
app.get("/cart", function (req, res) {
    res.render("cart");
})
// thanhtoan
app.get("/thanhtoan", function (req, res) {
    res.render("thanhtoan");
})

app.post("/thanhtoan", function (req, res) {
    let sanpham = JSON.parse(req.body.txtDonhang);
    // upload file
    upload(req, res, function(err){
        if (err instanceof multer.MulterError) {
            res.json({"kq": 0, "errMsg":"A Multer error occurred when uploading."});
        }
        else if (err) {
            res.json({"kq": 0, "errMsg": "An unknown error occurred when uploading." + err});
        }
        else{
            // save mongo
            var khachhang = Khachhang({
                Name: req.body.txtName,
                Address: req.body.txtAddress,
                Phone: req.body.txtPhone,
                DonHang: JSON.parse(req.body.txtDonhang)
            });
            khachhang.save(function (err) {
                if (err) {
                    res.json({"kq": 0, "errMsg": err});
                }
                else{
                    res.redirect("./");
                }
            })
            // giam so luong san pham trong kho
            
            for (let i = 0; i < sanpham.length; i++) {
                var soluong = 0;
                Laptop.findOne({Name : sanpham[i].name}, function (err, data) {
                    if (err) {
                        res.json({"kq": 0, "errMsg": err});
                    }
                    else{
                        soluong = data.Remains;
                        Laptop.updateOne({Name: sanpham[i].name}, {
                            Remains: soluong - sanpham[i].quantity
                            }, function (err) {
                            if (err) {
                                res.json({"kq": 0, "errMsg": err});
                            }
                        })
                    }
                })
            }
        }
    });
});