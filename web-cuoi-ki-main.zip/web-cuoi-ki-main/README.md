# web-cuoi-ki
laptop shop

--------setup---------

dán từng câu lệnh dưới này vào

cd Laptop Shop

npm run start

--------run-----------
mở trình duyệt lên rồi dán link này vào
localhost:3000
để qua trang admin thì dán link này
localhost:3000/admin/list
