var mongoose = require("mongoose");

var schemaKhachhang = new mongoose.Schema({
    Name: String,
    Address: String,
    Phone: String,
    DonHang: {}
});

module.exports = mongoose.model("Khachang", schemaKhachhang);