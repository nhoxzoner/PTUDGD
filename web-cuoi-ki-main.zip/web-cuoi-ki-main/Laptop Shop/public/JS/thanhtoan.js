'use strict';

let cart = (JSON.parse(localStorage.getItem('cart')) || []);
const addToCartButtonsDOM = document.querySelectorAll('[data-action="ADD_TO_CART"]');

// hàm xử lý của nút add to cart
addToCartButtonsDOM.forEach(addToCartButtonDOM => {
    addToCartButtonDOM.addEventListener('click', () => {
      const productDOM = addToCartButtonDOM.parentNode;
      const product = {
        image: productDOM.querySelector('.product__image').getAttribute('src'),
        name: productDOM.querySelector('.product__name').innerText,
        price: productDOM.querySelector('.product__price').innerText,
        quantity: 1,
      };
      // check coi món này có nằm trong localstorage chưa
      const isInCart = (cart.filter(cartItem => (cartItem.name === product.name)).length > 0);
      // nếu chưa có thì add vào
      if (!isInCart) {
        cart.push(product);
        saveCart();
      }
    });
  });

// save cart to localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}
