'use strict';

let cart = (JSON.parse(localStorage.getItem('cart')) || []);
const cartDOM = document.querySelector('.cart');

// check cart empty in localstorage
// có cart thì đưa ra màn hình ko có cart thì thôi :)))
if (cart.length > 0) {
    cart.forEach(cartItem => {
        const product = cartItem;
        insertItemToDOM(product);
        countCartTotal();
    });
}

// insert cart to bill
function insertItemToDOM(product) {
    cartDOM.insertAdjacentHTML('beforeend', `
    <div class="cart__item">
    <img class="cart__item__image" src="${product.image}" alt="${product.name}">
    <p class="cart__item__name">${product.name}</p>
    <p class="cart__item__price">${product.price} VNĐ</p>
    <p class="cart__item__quantity">${product.quantity}</p>
    </div>
    `);
    
    addCartFooter();
}

// tính tiền
function countCartTotal() {
  let cartTotal = 0;
  cart.forEach(cartItem => cartTotal += cartItem.quantity * cartItem.price);
  document.querySelector('[data-action="CLEAR_CART"]').innerText = `Tổng: ${cartTotal} VNĐ`;
}

// them nut pay vs nut clear
function addCartFooter() {
  if (document.querySelector('.cart-footer') === null) {
      cartDOM.insertAdjacentHTML('afterend', `
      <div class="cart-footer">
      <p class="tong_tien" data-action="CLEAR_CART">$</p>
      </div>
    `);
    document.querySelector('[data-action="CLEAR_CART"]').addEventListener('click', () => clearCart());
  }
}

var x = document.getElementById("donhang");
x.value = localStorage.getItem('cart')