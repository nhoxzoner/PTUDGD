
const giohang = document.getElementById('giohang');
const str = localStorage.getItem('cart');

let count = 0;

for (let i = 0; i < str.length; i++) {
    if (str[i] ==='{' || str[i] === '}') {
        count = count + 1;
    }    
}

if (localStorage.getItem("cart") !== null) {
    giohang.innerHTML = count/2;
}
